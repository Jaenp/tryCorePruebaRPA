from flask import Blueprint, request, jsonify
from database import db
from models import Empresa

# Usamos Blueprint para organizar los endpoints
routes = Blueprint("routes", __name__)

# ------------------------------
# Endpoint 1: Registrar Empresa
# ------------------------------
@routes.route("/process-data", methods=["POST"])
def process_data():
    data = request.get_json()  # Capturamos JSON enviado por el cliente
    if not data or "nit" not in data:
        return jsonify({"error": "El campo 'nit' es obligatorio, 400"}), 400

    # Verificar si ya existe el NIT en BD
    if Empresa.query.filter_by(nit=data["nit"]).first():
        return jsonify({"message": "La empresa ya existe, 400"}), 400

    try:
        # Crear registro en la BD
        empresa = Empresa(nit=data["nit"], datos=data.get("datos"))
        db.session.add(empresa)
        db.session.commit()
        return jsonify({"error": "Empresa registrada correctamente, 201"}), 201
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ------------------------------
# Endpoint 2: Actualizar Estado
# ------------------------------
@routes.route("/update-status", methods=["POST"])
def update_status():
    data = request.get_json()
    if not data or "nit" not in data or "estado" not in data:
        return jsonify({"error": "Se requieren los campos 'nit' y 'estado', 400"}), 400

    # 🔹 Validar que el estado enviado sea válido
    if data["estado"] not in ["PENDIENTE", "PROCESADO", "ERROR"]:
        return jsonify({"error": "Estado no válido, 400"}), 400

    empresa = Empresa.query.filter_by(nit=data["nit"]).first()
    if not empresa:
        return jsonify({"error": "Empresa no encontrada, 404"}), 404

    try:
        empresa.estado = data["estado"]
        db.session.commit()
        return jsonify({"message": f"Estado de empresa {empresa.nit} actualizado a {empresa.estado}, 200"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500