# Backend RPA - Prueba Técnica

## 🚀 Instalación

git clone <https://github.com/Jaenp/tryCorePruebaRPA>
cd backend_rpa
python -m venv venv
venv\Scripts\activate   # Windows
source venv/bin/activate   # Linux/Mac
pip install -r requirements.txt