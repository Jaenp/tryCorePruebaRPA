from flask_sqlalchemy import SQLAlchemy

# Inicializamos SQLAlchemy, que será usado en toda la app
db = SQLAlchemy()
