from database import db

class Empresa(db.Model):
    __tablename__ = "empresas"   # Nombre de la tabla en la BD

    id = db.Column(db.Integer, primary_key=True)  # ID autoincremental
    nit = db.Column(db.String(50), unique=True, nullable=False)  # NIT único
    estado = db.Column(db.String(20), default="PENDIENTE")  # Estado de proceso
    datos = db.Column(db.JSON, nullable=True)  # Datos capturados (ej. razón social, dirección, etc.)
